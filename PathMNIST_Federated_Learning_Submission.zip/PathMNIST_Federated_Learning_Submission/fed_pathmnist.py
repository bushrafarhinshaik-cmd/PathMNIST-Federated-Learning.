import argparse, copy, csv, os, random
from pathlib import Path
import numpy as np
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader, Subset
import medmnist
from medmnist import INFO
import matplotlib.pyplot as plt

def seed_everything(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

class ArrayDataset(Dataset):
    def __init__(self, images, labels):
        self.images, self.labels = images, labels
    def __len__(self): return len(self.labels)
    def __getitem__(self, i):
        x = self.images[i]
        if x.ndim == 2: x = np.repeat(x[..., None], 3, axis=-1)
        x = torch.tensor(x, dtype=torch.float32).permute(2,0,1) / 255.0
        y = int(self.labels[i])
        return x, y

class SmallCNN(nn.Module):
    def __init__(self, n_classes=9):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3,32,3,padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(32,64,3,padding=1), nn.ReLU(), nn.MaxPool2d(2),
            nn.Conv2d(64,128,3,padding=1), nn.ReLU(),
            nn.AdaptiveAvgPool2d(1))
        self.classifier = nn.Linear(128,n_classes)
    def forward(self,x): return self.classifier(self.features(x).flatten(1))

def dirichlet_partition(labels, n_clients, alpha, seed):
    rng = np.random.default_rng(seed)
    labels = np.asarray(labels).reshape(-1)
    buckets = [[] for _ in range(n_clients)]
    for cls in np.unique(labels):
        idx = np.where(labels == cls)[0]
        rng.shuffle(idx)
        proportions = rng.dirichlet(np.repeat(alpha,n_clients))
        cuts = (np.cumsum(proportions)[:-1] * len(idx)).astype(int)
        for client, part in enumerate(np.split(idx,cuts)):
            buckets[client].extend(part.tolist())
    for b in buckets: rng.shuffle(b)
    return buckets

def inject_noise(labels, fraction, n_classes, seed):
    rng = np.random.default_rng(seed)
    noisy = np.asarray(labels).reshape(-1).copy()
    count = int(round(len(noisy)*fraction))
    chosen = rng.choice(len(noisy), count, replace=False)
    for i in chosen:
        offset = rng.integers(1,n_classes)
        noisy[i] = (int(noisy[i]) + int(offset)) % n_classes
    return noisy

def evaluate(model, loader, device):
    model.eval(); correct=total=0
    with torch.no_grad():
        for x,y in loader:
            x,y=x.to(device),y.to(device)
            pred=model(x).argmax(1)
            correct += (pred==y).sum().item(); total += len(y)
    return correct/max(total,1)

def state_delta(new, old):
    return {k: new[k].detach().cpu()-old[k].detach().cpu() for k in new}

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--rounds",type=int,default=20); p.add_argument("--local-epochs",type=int,default=1)
    p.add_argument("--batch-size",type=int,default=128); p.add_argument("--lr",type=float,default=0.01)
    p.add_argument("--clients",type=int,default=5); p.add_argument("--alpha",type=float,default=0.3)
    p.add_argument("--noise",type=float,default=0.4); p.add_argument("--noise-client",type=int,default=0)
    p.add_argument("--mu",type=float,default=0.01); p.add_argument("--seed",type=int,default=0)
    p.add_argument("--wandb-project",default="pathmnist-fedavg-fedprox"); p.add_argument("--no-wandb",action="store_true")
    p.add_argument("--output",default="outputs")
    args=p.parse_args()
    seed_everything(args.seed)
    out=Path(args.output); out.mkdir(parents=True,exist_ok=True)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    info=INFO["pathmnist"]; DataClass=getattr(medmnist,info["python_class"])
    train_raw=DataClass(split="train",download=True)
    test_raw=DataClass(split="test",download=True)
    x_train,y_train=train_raw.imgs,train_raw.labels.reshape(-1)
    x_test,y_test=test_raw.imgs,test_raw.labels.reshape(-1)
    n_classes=len(np.unique(y_train))
    train_parts=dirichlet_partition(y_train,args.clients,args.alpha,args.seed)
    test_parts=dirichlet_partition(y_test,args.clients,args.alpha,args.seed+1)
    client_loaders=[]
    for cid,indices in enumerate(train_parts):
        labels=y_train[indices].copy()
        if cid==args.noise_client:
            labels=inject_noise(labels,args.noise,n_classes,args.seed+100+cid)
        ds=ArrayDataset(x_train[indices],labels)
        client_loaders.append(DataLoader(ds,batch_size=args.batch_size,shuffle=True,num_workers=0))
    test_loaders=[DataLoader(ArrayDataset(x_test[idx],y_test[idx]),batch_size=args.batch_size,shuffle=False,num_workers=0) for idx in test_parts]
    global_test=DataLoader(ArrayDataset(x_test,y_test),batch_size=args.batch_size,shuffle=False,num_workers=0)
    try:
        import wandb
        use_wandb=not args.no_wandb
    except ImportError:
        use_wandb=False
        if not args.no_wandb: print("wandb not installed; continuing without W&B")
    methods=[("fedavg",0.0),("fedprox",args.mu)]
    all_results={}
    for method,mu in methods:
        run=None
        if use_wandb:
            import wandb
            run=wandb.init(project=args.wandb_project,name=(f"fedavg_seed{args.seed}" if method=="fedavg" else f"fedprox_mu{mu}_seed{args.seed}"),config=vars(args)|{"method":method,"mu":mu},reinit=True)
        model=SmallCNN(n_classes).to(device)
        criterion=nn.CrossEntropyLoss()
        rows=[]
        for rnd in range(1,args.rounds+1):
            global_state={k:v.detach().clone() for k,v in model.state_dict().items()}
            client_states=[]; client_sizes=[]; losses=[]; deltas=[]
            for cid,loader in enumerate(client_loaders):
                local=SmallCNN(n_classes).to(device); local.load_state_dict(global_state)
                optimizer=torch.optim.SGD(local.parameters(),lr=args.lr,momentum=0.9)
                local.train(); loss_sum=0; batches=0
                for _ in range(args.local_epochs):
                    for xb,yb in loader:
                        xb,yb=xb.to(device),yb.to(device); optimizer.zero_grad()
                        logits=local(xb); loss=criterion(logits,yb)
                        if mu>0:
                            prox=sum(torch.sum((param-global_state[name].to(device))**2) for name,param in local.named_parameters())
                            loss=loss+(mu/2.0)*prox
                        loss.backward(); optimizer.step()
                        loss_sum += loss.item(); batches += 1
                state={k:v.detach().cpu().clone() for k,v in local.state_dict().items()}
                client_states.append(state); client_sizes.append(len(loader.dataset))
                losses.append(loss_sum/max(batches,1))
                deltas.append(state_delta(state,{k:v.detach().cpu() for k,v in global_state.items()}))
                del local
            total=sum(client_sizes)
            new_state={}
            for key in global_state:
                new_state[key]=sum(client_states[i][key]* (client_sizes[i]/total) for i in range(args.clients))
            model.load_state_dict(new_state)
            global_acc=evaluate(model,global_test,device)
            per_client=[evaluate(model,loader,device) for loader in test_loaders]
            norms=[float(torch.sqrt(sum(torch.sum(v.float()**2) for v in d.values())).item()) for d in deltas]
            mean_delta={k:sum(d[k] for d in deltas)/len(deltas) for k in deltas[0]}
            cosines=[]
            for d in deltas:
                dot=sum(torch.sum(d[k].float()*mean_delta[k].float()) for k in d)
                a=torch.sqrt(sum(torch.sum(d[k].float()**2) for k in d))
                b=torch.sqrt(sum(torch.sum(mean_delta[k].float()**2) for k in mean_delta))
                cosines.append(float((dot/(a*b+1e-12)).item()))
            row={"method":method,"round":rnd,"global_accuracy":global_acc,"mean_train_loss":float(np.mean(losses))}
            row.update({f"client_{i}_accuracy":per_client[i] for i in range(args.clients)})
            row.update({f"client_{i}_update_norm":norms[i] for i in range(args.clients)})
            row.update({f"client_{i}_cosine":cosines[i] for i in range(args.clients)})
            rows.append(row)
            print(f"{method} round {rnd}/{args.rounds}: global_acc={global_acc:.4f}, client_acc={[round(a,4) for a in per_client]}")
            if run: run.log(row,step=rnd)
        all_results[method]=rows
        if run: run.finish()
    csv_path=out/"metrics.csv"
    keys=list(all_results["fedavg"][0].keys())
    with csv_path.open("w",newline="") as f:
        writer=csv.DictWriter(f,fieldnames=keys); writer.writeheader()
        for method in methods:
            writer.writerows(all_results[method[0]])
    plt.figure(figsize=(8,5))
    for method,_ in methods:
        plt.plot([r["round"] for r in all_results[method]],[r["global_accuracy"] for r in all_results[method]],label=method.upper())
    plt.xlabel("Communication round"); plt.ylabel("Global test accuracy"); plt.title("PathMNIST: FedAvg vs FedProx")
    plt.legend(); plt.grid(alpha=.25); plt.tight_layout(); plt.savefig(out/"global_accuracy_comparison.png",dpi=160); plt.close()
    final=[]
    for method,_ in methods:
        r=all_results[method][-1]
        final.append({"method":method,"global_accuracy":r["global_accuracy"],**{f"client_{i}_accuracy":r[f"client_{i}_accuracy"] for i in range(args.clients)}})
    with (out/"final_accuracy_summary.json").open("w") as f:
        import json; json.dump(final,f,indent=2)
    print(f"Saved results to {out.resolve()}")

if __name__=="__main__": main()