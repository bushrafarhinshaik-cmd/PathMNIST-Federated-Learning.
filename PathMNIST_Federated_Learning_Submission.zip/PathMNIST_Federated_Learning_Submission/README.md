# PathMNIST Federated Learning: FedAvg vs FedProx

This project compares FedAvg and FedProx on PathMNIST (MedMNIST) using 5 clients and a non-IID Dirichlet partition (alpha=0.3). It injects 40% label noise into the training labels of client 0.

## Setup
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
wandb login
```

## Run
```bash
python fed_pathmnist.py --rounds 20 --local-epochs 1 --clients 5 --alpha 0.3 --noise 0.4 --noise-client 0
```
For a local test without W&B:
```bash
python fed_pathmnist.py --rounds 1 --no-wandb
```

The script creates `outputs/metrics.csv`, `outputs/global_accuracy_comparison.png`, and `outputs/final_accuracy_summary.json`. W&B logs global accuracy, per-client clean test accuracy, mean local training loss, per-client update L2 norms, and cosine similarity between each client update and the mean client update.

## Method details
- **FedAvg:** sample-count-weighted average of client model parameters.
- **FedProx:** adds `(mu/2) * ||w_local - w_global||^2` to each client's local loss; server aggregation remains sample-count-weighted FedAvg.
- **Data split:** class-wise Dirichlet allocation with alpha 0.3.
- **Noise:** 40% of client 0's local training labels are changed to a different class. Test labels remain clean.
- **Per-client accuracy:** the aggregated global model is evaluated on each client's clean held-out test partition.

## Notes
This is a standalone PyTorch implementation, not a modified PFLlib checkout. The experiment must be run to obtain real metrics; do not report estimated accuracy. Keep the W&B project public if the task requires a public URL. Create one public project named `pathmnist-fedavg-fedprox`; the script creates separate, clearly named runs for FedAvg and FedProx.

## Submission checklist
- [ ] Run both methods and inspect the generated plot and CSV.
- [ ] Verify both W&B runs are visible in the public project.
- [ ] Push this folder to a public GitHub repository.
- [ ] Add the GitHub URL, public W&B URL, and Part A PDF to the fellowship email reply.
