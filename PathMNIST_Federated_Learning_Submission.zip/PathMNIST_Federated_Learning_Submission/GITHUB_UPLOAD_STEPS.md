# Publish this project on GitHub

1. Sign in at https://github.com/.
2. Choose **New repository**.
3. Repository name: `PathMNIST-Federated-Learning`.
4. Set visibility to **Public** if the task requires a public repository.
5. Create the repository.
6. Choose **Add file → Upload files**.
7. Upload `fed_pathmnist.py`, `README.md`, `requirements.txt`, `.gitignore`, and `PathMNIST_FedAvg_FedProx_Colab.ipynb` from this folder.
8. Commit the files and copy the repository URL.

Do not upload W&B API keys, passwords, or private credentials. Do not upload generated metrics until the experiment has actually run.
